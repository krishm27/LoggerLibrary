﻿using LoggerLibrary.DomainObjects;
using LoggerLibrary.Enums;
using LoggerLibrary.Loggers;

namespace LoggerLibrary.Helpers
{
    public class LogHelper
    {
        private BaseLogger logger;
        public string FilePath { get; set; }
        public string ConnectionString { get; set; }

        public void Log(Message message)
        {
            if (string.IsNullOrEmpty(FilePath))
            {
                FilePath = @"D:\LoggerLibraryLog.txt";
            }

            if (string.IsNullOrEmpty(ConnectionString))
            {
                ConnectionString = "Server=.\\SQLEXPRESS;Database=LoggerLibrary;Trusted_Connection=true";
            }

            switch(message.MessageLevel)
            {
                case MessageLevel.FATAL: case MessageLevel.ERROR:
                    logger = new DatabaseLogger(ConnectionString);
                        break;
                case MessageLevel.WARN:
                    logger = new FileLogger(FilePath);
                    break;
                case MessageLevel.INFO: case MessageLevel.DEBUG:
                    logger = new ConsoleLogger();
                    break;
            }

            logger.Log(message);
        }
    }
}
