﻿using LoggerLibrary.Enums;

namespace LoggerLibrary.DomainObjects
{
    public class Message
    {
        public string Content { get; set; }
        public MessageLevel MessageLevel { get; set; }
        public string MessageNamespace { get; set; }

        public Message(string strContent, MessageLevel level, string msgNamespace)
        {
            this.Content = strContent;
            this.MessageLevel = level;
            this.MessageNamespace = msgNamespace;
        }

        public string GetFormattedMessage()
        {
            return $"{DateTime.Now} {this.MessageLevel} {this.Content} {this.MessageNamespace}";
        }
    }
}
