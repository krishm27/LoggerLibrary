﻿using LoggerLibrary.DomainObjects;

namespace LoggerLibrary.Loggers
{
    public class ConsoleLogger : BaseLogger
    {
        public override void Log(Message message)
        {
            Console.WriteLine(message.GetFormattedMessage());
        }
    }
}
