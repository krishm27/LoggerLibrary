﻿using LoggerLibrary.DomainObjects;
using System.Data.SqlClient;

namespace LoggerLibrary.Loggers
{
    public class DatabaseLogger : BaseLogger
    {
        private string connectionString;
        public DatabaseLogger(string connStr)
        {
            connectionString = connStr;
        }

        public override void Log(Message message)
        {
            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = connectionString;
                conn.Open();

                SqlCommand insertCommand = new SqlCommand("INSERT INTO Logs (LogDateTime, LogLevel, LogContent, MessageNamespace) VALUES (@LogDateTime, @LogLevel, @LogContent, @MessageNamespace)", conn);

                insertCommand.Parameters.Add(new SqlParameter("LogDateTime", DateTime.Now));
                insertCommand.Parameters.Add(new SqlParameter("LogLevel", message.MessageLevel));
                insertCommand.Parameters.Add(new SqlParameter("LogContent", message.Content));
                insertCommand.Parameters.Add(new SqlParameter("MessageNamespace", message.MessageNamespace));

                insertCommand.ExecuteNonQuery();

                conn.Close();
            }
        }
    }
}
