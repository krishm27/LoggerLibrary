﻿using LoggerLibrary.DomainObjects;

namespace LoggerLibrary.Loggers
{
    public abstract class BaseLogger
    {
        public abstract void Log(Message message);
    }
}
