﻿using LoggerLibrary.DomainObjects;

namespace LoggerLibrary.Loggers
{
    public class FileLogger : BaseLogger
    {
        private string filePath;
        public FileLogger(string path)
        {
            filePath = path;
        }

        public override void Log(Message message)
        {
            using (StreamWriter streamWriter = new StreamWriter(filePath))
            {
                streamWriter.WriteLine(message.GetFormattedMessage());
                streamWriter.Close();
            }
        }
    }
}
