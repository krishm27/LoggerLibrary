﻿namespace LoggerLibrary.Enums
{
    public enum MessageLevel
    {
        FATAL = 0,
        ERROR = 1,
        WARN = 2,
        INFO = 3,
        DEBUG = 4
    }
}
