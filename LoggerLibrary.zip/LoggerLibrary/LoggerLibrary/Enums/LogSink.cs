﻿namespace LoggerLibrary.Enums
{
    public enum LogSink
    {
        File = 0,
        Database = 1,
        Console = 2
    }
}
