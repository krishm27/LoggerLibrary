﻿// See https://aka.ms/new-console-template for more information
using LoggerLibrary.DomainObjects;
using LoggerLibrary.Enums;
using LoggerLibrary.Helpers;
using System.Reflection;

string currentNamespace = MethodBase.GetCurrentMethod()?.DeclaringType?.Namespace ?? string.Empty;
Message fatalMessage = new Message("Test 1", MessageLevel.FATAL, currentNamespace);
LogHelper fatalLogHelper = new LogHelper();
fatalLogHelper.Log(fatalMessage);
Message errorMessage = new Message("Test 2", MessageLevel.ERROR, currentNamespace);
LogHelper errorLogHelper = new LogHelper();
errorLogHelper.Log(errorMessage);
Message warnMessage = new Message("Test 3", MessageLevel.WARN, currentNamespace);
LogHelper warnLogHelper = new LogHelper();
warnLogHelper.Log(warnMessage);
Message infoMessage = new Message("Test 4", MessageLevel.INFO, currentNamespace);
LogHelper infoLogHelper = new LogHelper();
infoLogHelper.Log(infoMessage);
Message debugMessage = new Message("Test 5", MessageLevel.DEBUG, currentNamespace);
LogHelper debugLogHelper = new LogHelper();
debugLogHelper.Log(debugMessage);
